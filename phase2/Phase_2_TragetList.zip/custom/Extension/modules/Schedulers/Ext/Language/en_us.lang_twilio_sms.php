<?php

$mod_strings['LBL_TWILIOSMSSYNC'] = 'SMS Sync'; 
$mod_strings['LBL_SENDBULKSMS'] = 'Send Bulk SMS'; 

?>
<?php
require_once('custom/include/twilioConfiguration.php');
/*
* Start Send Target List SMS
*/
array_push($job_strings, 'SendTargetListSMS');
function SendTargetListSMS($job)
{
	global $db;
    //////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            $GLOBALS['log']->debug("Twilio Ninja is no longer active due to the following reason: ".$validate_license." Users will have limited to no access until the issue has been addressed.. ");
            return false;
            //functionality may be altered here in response to the key failing to validate
        }
    ////////////////////////////

    $data = unserialize(base64_decode($job->data));
	$smsText = $data['smsText'];
	$targetListID = $data['targetListID'];
	$selectedLists = $data['selectedLists'];
	if (empty($smsText) || empty($targetListID) || empty($selectedLists)) {
		$GLOBALS['log']->error('Failed is Job execution: SMS is empty or targetListID not found or selectedLists is not available');
		return;
	}


	$selectedLists = implode('","', $selectedLists);
	$targetIN = 'IN ( "' . $selectedLists . '" ) ';
	$targetRecords = getTargetListRecords($targetIN, $targetListID);
	foreach ($targetRecords as $key => $value) {
		$phoneIN = implode('","', $value);
		$phoneIN = 'IN ( "' . $phoneIN . '" ) ';
		$query = 'SELECT phone_mobile from '.strtolower($key). ' WHERE id '. $phoneIN;
		$res = $db->query($query);
		while ($row = $db->fetchByAssoc($res)) {
			if(!empty($row['phone_mobile'])) {
				sendSMS($row['phone_mobile'], $smsText);
			}
		}
	}

	return true;
}
/*
* Get Target List associated records
*/
function getTargetListRecords($targetIN, $targetListID)
{
	global $db;
	$query = 'SELECT related_id, related_type from prospect_lists_prospects WHERE related_type '.$targetIN.' AND prospect_list_id = '.$db->quoted($targetListID);
	$res = $db->query($query);
	$records = array();
	while ($row = $db->fetchByAssoc($res)) {
		if($row['related_type'] == 'Leads') {
			$records['Leads'][] = $row['related_id'];
 		} else if($row['related_type'] == 'Contacts') {
			$records['Contacts'][] = $row['related_id'];
		} else if($row['related_type'] == 'Prospects') {
			$records['Prospects'][] = $row['related_id'];
		}
	}
	return $records;
}

/*
* Start Send Bulk SMS
*/
array_push($job_strings, 'SendBulkSMS');
function SendBulkSMS($job)
{    
    //////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            $GLOBALS['log']->debug("Twilio Ninja is no longer active due to the following reason: ".$validate_license." Users will have limited to no access until the issue has been addressed.. ");
            return false;
            //functionality may be altered here in response to the key failing to validate
        }
    ////////////////////////////
    if (!empty($job->data))
    {
    	$data = unserialize(base64_decode($job->data));
    	$currentModule = $data['currentModule'];
    	$selectedRecordIds = $data['selectedRecordIds'];
    	$smsText = $data['smsText'];
    	if (empty($currentModule) || empty($smsText) || empty($selectedRecordIds)) {	    		
			$GLOBALS['log']->fatal('Send Bulk SMS Job Fail => SMS is empty or Selected records IDs not found or currentModule is not available');
			return false;
    	}

    	global $db;
    	$selectedRecordIds = implode('","', $selectedRecordIds);
    	$idsIn = 'IN ( "' . $selectedRecordIds . '" ) ';
    	$tabeleName = strtolower($currentModule);
    	$query = "SELECT t.phone_mobile phone from $tabeleName t where t.id " . $idsIn;
    	$records = $db->query($query);
    	while ($row = $db->fetchByAssoc($records)) {
            if (!empty($row['phone'])) {
                sendSMS($row['phone'], $smsText);
            }
    	}
        return true;        
    }
}

function sendSMS($toNumber, $smsText)
{
    require_once("modules/sp_sms_log/sp_sms_log.php");                  
    $sp_sms_log = new sp_sms_log();
    $sp_sms_log->message = $smsText;                                        
    $sp_sms_log->date_sent = gmdate('Y-m-d H:i:s', time());
    $sp_sms_log->status = "sending";
    $sp_sms_log->direction = "outgoing";
    $sp_sms_log->destination = $toNumber;  
    $sp_sms_log->scheduledJob = true;  
    $sp_sms_log->save();    // sending and saving SMS
}
/*
* End Send Bulk SMS
*/
////////////////////////////////////////////////////////////////////////////////////////////////

/*
* Start Send Schduled SMS
*/

array_push($job_strings, 'SendScheduledSMS');
function SendScheduledSMS($job)
{    
    //////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            $GLOBALS['log']->debug("Twilio Ninja is no longer active due to the following reason: ".$validate_license." Users will have limited to no access until the issue has been addressed.. ");
            return false;
            //functionality may be altered here in response to the key failing to validate
        }
    ////////////////////////////
    if (!empty($job->data))
    {
    	$data = unserialize(base64_decode($job->data));

        $sms_text = $data['sms_text'];
        $source_number = $data['source_number'];
        $destination_number = $data['destination_number'];
        $direction = $data['direction'];
        $dateScheduled = $data['dateScheduled'];
        $scheduled = $data['scheduled'];
        $smsID = $data['id'];
        if (empty($sms_text) || empty($source_number) || empty($destination_number) || empty($dateScheduled)) {
            $GLOBALS['log']->fatal('sms_text OR source_number OR destination_number OR dateScheduled is empty');
            return false;
        }
        require_once("modules/sp_sms_log/sp_sms_log.php");
        $sp_sms_log = BeanFactory::getBean('sp_sms_log', $smsID);
        $sp_sms_log->message = $sms_text;                                        
        $sp_sms_log->date_sent = gmdate('Y-m-d H:i:s', time());
        $sp_sms_log->status = "sending";
        $sp_sms_log->direction = "outgoing";
        $sp_sms_log->destination = $destination_number;
        $sp_sms_log->dateScheduled = $dateScheduled; 
        $sp_sms_log->scheduled = $scheduled;   
        $sp_sms_log->scheduledJob = true;  
        $sp_sms_log->save();    // sending and saving SMS

        return true;        
    }
}
/*
* End Send Schduled SMS
*/
////////////////////////////////////////////////////////////////////////////////////////////////
/*
* Sync SMS Log with twilio
*/

use Twilio\Rest\Client;
use \Twilio\Exceptions\RestException;
array_push($job_strings, 'twilioSMSSync');
function twilioSMSSync()
{
	require_once("modules/sp_sms_log/sp_sms_log.php");       
	//////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            $GLOBALS['log']->fatal("Twilio Ninja is no longer active due to the following reason: ".$validate_license." Users will have limited to no access until the issue has been addressed.. ");
            return false;
            //functionality may be altered here in response to the key failing to validate
        }
    ////////////////////////////
	$sp_sms_log = new sp_sms_log();
	
	try{
		$client = $sp_sms_log->getClient();
		if(!(is_object($client) && $client instanceof Client)) {
            $GLOBALS['log']->fatal("sendSMS : unable to get client object....... ");
            return false;           
        }
		
		$order_by = 'date_entered DESC';
		$where = " ".$sp_sms_log->table_name.".`status` = 'queued' OR ".$sp_sms_log->table_name.".`status` = 'undelivered' OR ".$sp_sms_log->table_name.".`status` = 'sending' OR ".$sp_sms_log->table_name.".`status`='scheduled' OR (".$sp_sms_log->table_name.".`status`='sent') ";
		$list = $sp_sms_log->get_list($order_by,$where);		
		if ($list['row_count'] > 0)
		{
			foreach ($list['list'] as $sms_log)
			{
				$sp_sms_log->updateStatus($sms_log->reference_id);
			}
		}
				    
		$messages_array = array();
		$message_ids = array();
		$direction_map = array(
			'inbound' => 'incoming',
			'outbound' => 'outgoing',
			'outbound-api' => 'outgoing',
			'outbound-reply' => 'outgoing',
		);

		$config = TwilioConfiguration::getConfig();
        $phone_number = $config[2];
		$GLOBALS['log']->debug("Getting the messages");
		// Get the messages
		foreach($client->messages->read() as $message)
		{
			$message_data = $message;
			// If the messages are associated with the number stored in the Twiliio Account then get the data.
			$GLOBALS['log']->debug("message_data : ",$message_data);
			if ((string)$message_data->to == $phone_number || (string)$message_data->from == $phone_number )
			{				
				$message_ids[] = (string)$message_data->sid;
				$o = new ReflectionObject($message_data->dateSent);
				$p = $o->getProperty('date');
				$dateSent = $p->getValue($message_data->dateSent);

				$GLOBALS['log']->debug("Prepare Array ",$message_data);


				$data = array(
					'reference_id' => (string)$message_data->sid,
					'date_sent' => gmdate('Y-m-d H:i:s',strtotime((string)$dateSent)),
					'account' => (string)$message_data->sid,
					'destination' => (string)$message_data->to,
					'origin' => (string)$message_data->from,
					'message' => (string)$message_data->body,
					'status' => (string)$message_data->status,
					'direction' => $direction_map[(string)$message_data->direction],
					'url' => (string)$message_data->uri
				);
				
				if (strtotime((string)$dateSent) > strtotime('2012-11-14 17:0:00 +0000'))
				{
					if ((string)$message_data->direction == 'inbound')
					{
						$messages_array['incoming'][] = $data;
					}
					else if (preg_match('/outbound/i',(string)$message_data->direction))
					{
						$messages_array['outgoing'][] = $data;
					}
				}
			}
		}
		
		// Get the records already saved in the system
		$query = "SELECT `reference_id`,`status`,`need_sync`,`id` FROM sp_sms_log WHERE reference_id IN ('".implode("','",$message_ids)."')";
		$already_synced = array();
		$existing_data = array();
		$rs = $GLOBALS['db']->query($query);
		while ($row = $GLOBALS['db']->fetchByAssoc($rs))
		{
			$already_synced[] = $row['reference_id'];
			$existing_data[$row['reference_id']] = $row;
		}
		// Sync the Incoming messages
		require_once('modules/sp_sms_log/sp_sms_log.php');
		foreach($messages_array['incoming'] as $incoming_message)
		{				
			$sms_log = new sp_sms_log();
						
			if (!in_array($incoming_message['reference_id'],$already_synced))
			{
				$GLOBALS['log']->debug("saving incoming_message ",$incoming_message);

				$sms_log->assigned_user_id = '1';
				$sms_log->from_sync = "TwilioSync";
				$sms_log->reference_id = $incoming_message['reference_id'];
				$sms_log->date_sent = $incoming_message['date_sent'];
				$sms_log->account = $incoming_message['account'];
				$sms_log->destination = $incoming_message['destination'];
				$sms_log->origin = $incoming_message['origin'];
				$sms_log->message = removeEmoji($incoming_message['message']);
				$sms_log->status = $incoming_message['status'];
				$sms_log->direction = $incoming_message['direction'];
				$sms_log->url = $incoming_message['url'];
					
				if($sms_log->direction == "inbound" || $sms_log->direction == "incoming")
					$sms_log->save();			
			}
		}
	
		// Sync the Outgoing messages
		foreach($messages_array['outgoing'] as $outgoing_message)
		{	
			$sms_log = new sp_sms_log();
			
			if (!in_array($outgoing_message['reference_id'],$already_synced) || $existing_data[$outgoing_message['reference_id']]['need_sync'] == '1')
			{
				if (in_array($outgoing_message['reference_id'],$already_synced))
				{
					$sms_log->id = $existing_data[$outgoing_message['reference_id']]['id'];
				}
				$GLOBALS['log']->debug("saving outgoing_message ",$outgoing_message);
				$sms_log->assigned_user_id = '1';
				$sms_log->from_sync = "TwilioSync";
				$sms_log->reference_id = $outgoing_message['reference_id'];
				$sms_log->date_sent = $outgoing_message['date_sent'];
				$sms_log->account = $outgoing_message['account'];
				$sms_log->destination = $outgoing_message['destination'];
				$sms_log->origin = $outgoing_message['origin'];
				$sms_log->message = removeEmoji($outgoing_message['message']);
				if ($outgoing_message['status'] =='delivered')
				{
					$sms_log->status = "sent";
				}
				else
				{
					$sms_log->status = $outgoing_message['status'];
				}
				$sms_log->direction = $outgoing_message['direction'];
				$sms_log->url = $outgoing_message['url'];
				$sms_log->save();
			}
		}	
		
	} catch (RestException $e) {
        $GLOBALS['log']->fatal('Failed While Sync', $e->getMessage(  ) , __FUNCTION__);
	}
	return true;	
}

function removeEmoji($text) {

    $clean_text = "";

    // Match Emoticons
    $regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
    $clean_text = preg_replace($regexEmoticons, '', $text);

    // Match Miscellaneous Symbols and Pictographs
    $regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
    $clean_text = preg_replace($regexSymbols, '', $clean_text);

    // Match Transport And Map Symbols
    $regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
    $clean_text = preg_replace($regexTransport, '', $clean_text);

    // Match Miscellaneous Symbols
    $regexMisc = '/[\x{2600}-\x{26FF}]/u';
    $clean_text = preg_replace($regexMisc, '', $clean_text);

    // Match Dingbats
    $regexDingbats = '/[\x{2700}-\x{27BF}]/u';
    $clean_text = preg_replace($regexDingbats, '', $clean_text);

    return $clean_text;
}
<?php
	$entry_point_registry['sendBulkSMS'] = array(
	    'file' => 'modules/sp_sms_log/sendBulkSMS.php',
	    'auth' => true
	);
?>
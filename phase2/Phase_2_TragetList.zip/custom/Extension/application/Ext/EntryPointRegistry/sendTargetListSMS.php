<?php
	$entry_point_registry['sendTargetListSMS'] = array(
	    'file' => 'modules/sp_sms_log/sendTargetListSMS.php',
	    'auth' => true
	);
?>
<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['sp_sms_log'] = 'sp_sms_log';
$beanFiles['sp_sms_log'] = 'modules/sp_sms_log/sp_sms_log.php';
$moduleList[] = 'sp_sms_log';

?>
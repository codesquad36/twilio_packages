<?php

/**
* To get twilio configurations saved in sugar
*/

require_once('modules/Configurator/Configurator.php');
class TwilioConfiguration
{
	private static $category = 'twilio';
    private static $key = 'settings';

    /*
    * return settings
    * settings[0] => SID
    * settings[1] => AUTHTOKEN
    * settings[2] => Number
    */
	public static function getConfig()
	{
		$system_config = new Administration();
        $system_config->retrieveSettings(self::$category);
        $settings = explode('^', $system_config->settings[self::$category.'_'.self::$key]);
        return $settings;
	}
}
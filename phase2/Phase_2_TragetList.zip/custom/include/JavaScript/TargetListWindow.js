var SMS_making_f = true;
var TARGET_LIST_ID = '';
var dateScheduled = '';
$(document).ready(function(){
	var curr_module = $('#formDetailView [name="module"]').val();
	if(curr_module == "ProspectLists"){
		var element = document.createElement("input");
		//Assign different attributes to the element. 
		element.type = "button";
		element.value = "Send SMS";
		element.name = "send_sms";
		element.id = "send_sms";

		var parentGuest = document.getElementById("tab-actions");
		if(typeof(parentGuest) == "undefined" || parentGuest == "null" || parentGuest == null || parentGuest == ""){
			parentGuest = document.getElementById("delete_button");
			if(typeof(parentGuest) == "undefined" || parentGuest == "null" || parentGuest == null || parentGuest == ""){
				parentGuest = document.getElementById("formDetailView");
			}
		}
		if (parentGuest.nextSibling) {
		  parentGuest.parentNode.insertBefore(element, parentGuest.nextSibling);
		}
		else {
		  parentGuest.parentNode.appendChild(element);
		}

		$('#send_sms').click(function(){
			showChatWindow();
		});
	}

});


/*
* handle outgoing and incoming twilio SMS 	
*/
function showChatWindow()
{
	TARGET_LIST_ID = document.getElementsByName('record')[0].value;;
	$(".makeSMS").attr("disabled","disabled");

	makingSMSDiv();// Create dynamic div for making outbound call			
	
}


/*
*	SMS div dynamically n destroy that if no needed
*/
function makingSMSDiv() {
	if (document.getElementById('myModal')) 
	{
		//code if element exists
	} 
	else {
		var newChatClient = document.createElement('div');
		newChatClient.setAttribute("id", "myModal");
		newChatClient.setAttribute("class", "modal");
		document.body.appendChild(newChatClient);						
	}						
	chatWindowAppear();
}

function chatWindowAppear() {
	if (TARGET_LIST_ID == '' || typeof TARGET_LIST_ID == 'undefined') {
		alert('TARGET_LIST_ID is empty');
		return false;
	}
	chatObj = document.getElementById('myModal');
	var chatDiv = '<div class="modal-content">';
	chatDiv += '<div class="modal-header">';
	chatDiv += '<span class="number">Bulk SMS</span>';
	chatDiv += '<span onclick="hideChatWindow()" class="close">&times;</span>';
	chatDiv += '</div>';
	chatDiv += '<div class="smsComposeTL">';
    chatDiv += '<div class="smsText">';
    chatDiv += '<textarea id="sms_message" ></textarea>';
    chatDiv += '</div>';
    chatDiv += '<div>';
    chatDiv += '<input type="image" src="custom/include/twilio_images/send_sms.png" id="sms_sender" value="Send" width="70" height="50" onclick="sendSMS()">';
    chatDiv += '<div class = "listSelect"> <input type="checkbox" name="contacts" id="contacts" value="contacts"> Contacts <input type="checkbox" id="leads" name="leads" value="leads" checked> Leads <input type="checkbox" id="targets" name="targets" value="targets"> Target</div>';
    chatDiv += '<div class = "scheduled"><input type="checkbox" id="isScheduled" name="isScheduled"> Scheduled SMS<br><input type="datetime-local" id = "scheduledDate" name="scheduledDate" value=""></div>';
    chatDiv += '</div>';
    chatDiv += '</div>';
	chatDiv += '</div>';
	chatDiv += '</div>';
	
	chatObj.innerHTML = chatDiv;
	chatObj.style.display = 'block';
	postChatWindowFunction();

}
function postChatWindowFunction() {

	/*
	// Show/Hide datetime field for scheduled SMS
	*/
	$('input[name="scheduledDate"]').hide();
    $('input[name="isScheduled"]').on('click', function () {
        if ($(this).prop('checked')) {
        	scheduled = true;        	
            $('input[name="scheduledDate"]').fadeIn();
            $('input[name="scheduledDate"]').val(getCurrentDate() +'T'+ getCurrentTime());
        } else {	        		
        	scheduled = false;  
            $('input[name="scheduledDate"]').hide();
        }
    });


	
	$("#sms_message").keydown(function(e){
	    if (e.keyCode == 13 && !e.shiftKey)
	    {
			sendSMS();
	    }
	});
}
function getCurrentDate() {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!

	var yyyy = today.getFullYear();
	if(dd<10){
	    dd='0'+dd;
	} 
	if(mm<10){
	    mm='0'+mm;
	} 
	
	var today = yyyy+'-'+mm+'-'+dd;
	return today;
}

function getCurrentTime() {
	var time = new Date().toLocaleTimeString('en-US', { hour12: false, 
                                         hour: "numeric", 
                                         minute: "numeric"});
	return time;
}
function hideChatWindow() {
    chatObj.style.display = "none";
    SMS_window_open = false;
}


/*
*	this will send the Instant SMS Message to destination number and also save current SMS in Database
*/
function sendSMS() {
	var smsText = document.getElementById('sms_message').value;
	if (smsText == '') {
		$( ".smsText" ).animate({ backgroundColor: "#f00"}, 100, "swing", function(){$("#sms_message").text("Please type a message");});
		$( ".smsText" ).animate({ backgroundColor: "#fff"}, 1200, "swing", function(){$("#sms_message").text("");});
		return false;
		//return;
	}
	var leads = document.querySelector('#leads').checked;
	var contacts = document.querySelector('#contacts').checked;
	var targets = document.querySelector('#targets').checked;
	var islistSelected = false;
	var selectedLists = [];
	
	if(leads || contacts || targets) {
		islistSelected = true;
		if(leads) {
			selectedLists.push('Leads');
		}
		if (contacts) {

			selectedLists.push('Contacts');
		}
		if(targets) {
			selectedLists.push('Prospects');
		}
	}
	if(!islistSelected) {
		alert('Please Select One List');
		return false;
	}
	console.log('leads : ',leads);
	console.log('contacts : ',contacts);
	console.log('targets : ',targets);
	var scheduled = false;
	if(document.getElementById('isScheduled').checked) {
		dateScheduled = document.getElementById("scheduledDate").value;
		scheduled = true;
		if(dateScheduled == '') {
			alert('Scheduled Date is Empty');
			return false;
		}
	}

	var data = {
		smsText: smsText,
		targetListID: TARGET_LIST_ID,
		selectedLists: selectedLists,
		dateScheduled: dateScheduled,
		scheduled: scheduled
	};

	// Fire off the request to create job to send SMS
    request = $.ajax({
        url: 'index.php?entryPoint=sendTargetListSMS',
        type: "post",
        data: data
    });

    // Callback handler that will be called on success
    request.done(function (response, textStatus, jqXHR){
        // Log a message to the console
        hideChatWindow();
    });

    // Callback handler that will be called on failure
    request.fail(function (jqXHR, textStatus, errorThrown){
        // Log the error to the console
        console.error(
            "The following error occurred: "+
            textStatus, errorThrown
        );
    });
}
<?php

require_once('modules/Contacts/views/view.list.php');
require_once('custom/modules/Contacts/CustomContactsListViewSmarty.php');

class CustomContactsViewList extends ContactsViewList
{
    /**
     * @see ContactsViewList::preDisplay()
     */
    public function preDisplay(){
        parent::preDisplay();

        $this->lv = new CustomContactsListViewSmarty();
    }

}

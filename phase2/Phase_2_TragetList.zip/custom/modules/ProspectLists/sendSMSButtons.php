<?php
class AddSMSButtons {
  
	function add()
	{   
		//////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            echo '<p class="error">Twilio Ninja is no longer active due to the following reason: '.$validate_license.' Users will have limited to no access until the issue has been addressed.</p>';
            return;
            //functionality may be altered here in response to the key failing to validate
        }
        ////////////////////////////
		echo '<link type="text/css" rel="stylesheet" href="custom/include/twilio_css/popUp_bulk.css" /><script src="custom/include/JavaScript/TargetListWindow.js"></script>';
	}
}
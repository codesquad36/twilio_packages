.. twilio-php documentation master file, created by
   sphinx-quickstart on Thu Aug 11 13:48:59 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

twilio-php
==========

Hey there! You can find documentation for the latest versions of twilio-php
here:

    - **Version 5.x API docs:** https://twilio.github.io/twilio-php/
    - **Migration guide:** https://www.twilio.com/docs/libraries/php/migration-guide
    - **General documentation:** https://www.twilio.com/docs/libraries/php

.. note::

    Looking for API reference docs for twilio-php version 4.x?

    Check out http://twilio-php.readthedocs.io/en/4.11.0/

<?php


namespace Twilio\Tests\Unit;

use \PHPUnit_Framework_TestCase;

abstract class UnitTest extends PHPUnit_Framework_TestCase {

}
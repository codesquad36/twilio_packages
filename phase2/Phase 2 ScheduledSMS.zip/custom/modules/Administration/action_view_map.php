<?php

$action_view_map['twilioadmin'] = 'twilioadminconfig';
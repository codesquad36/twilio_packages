<?php
/**
* Add Custom Bulk Action in list view
*/
require_once('modules/Leads/LeadsListViewSmarty.php');
class CustomLeadsListViewSmarty extends LeadsListViewSmarty
{

	function process($file, $data, $htmlVar) {
        $this->actionsMenuExtraItems[] = $this->customBulkAction();
		parent::process($file, $data, $htmlVar);
	}


    protected function customBulkAction()
    {		       
        //////////////////
        
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            echo '<p class="error">Twilio Ninja is no longer active due to the following reason: '.$validate_license.' Users will have limited to no access until the issue has been addressed.</p>';
            return;
            //functionality may be altered here in response to the key failing to validate
        }
        
        
        //////////////////
    	$module = $this->seed->module_dir;
    	return "<script type=\"text/javascript\" src=\"custom/include/JavaScript/script.js\"></script> <link type=\"text/css\" rel=\"stylesheet\" href=\"custom/include/twilio_css/popUp_bulk.css\" /> <a href='javascript:void(0)' title=\"Click to Send Bulk SMS/Emails\" class=\"parent-dropdown-action-handler\" onclick=\"send_bulk_sms('{$module}');\" >Send Bulk SMS</a>";    
    }
}
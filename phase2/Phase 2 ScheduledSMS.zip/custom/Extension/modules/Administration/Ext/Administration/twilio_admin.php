<?php

$admin_option_defs = array();
$admin_option_defs['Administration']['twilio_admin'] = array(
    'twilio_admin',
    'LBL_TWILIO_ADMIN_TITLE',
    'LBL_TWILIO_ADMIN_DESC',
    './index.php?module=Administration&action=TwilioAdmin'
    );
    $admin_option_defs['Administration']['twilio_ninja']= array(
        'helpInline',
        'LBL_TWILIONINJA_LICENSE_TITLE',
        'LBL_TWILIONINJA_LICENSE',
        './index.php?module=sp_sms_log&action=license'
    );

$admin_group_header[] = array(
    'LBL_TWILIO_SETTINGS',
    '',
    false,
    $admin_option_defs,
    'LBL_TWILIO_SETTINGS_DESC'
    );
<?php
array_push($job_strings, 'SendScheduledSMS');

require_once('custom/include/twilioConfiguration.php');
function SendScheduledSMS($job)
{    
    //////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            $GLOBALS['log']->debug("Twilio Ninja is no longer active due to the following reason: ".$validate_license." Users will have limited to no access until the issue has been addressed.. ");
            return false;
            //functionality may be altered here in response to the key failing to validate
        }
    ////////////////////////////
    if (!empty($job->data))
    {
    	$data = unserialize(base64_decode($job->data));

        $sms_text = $data['sms_text'];
        $source_number = $data['source_number'];
        $destination_number = $data['destination_number'];
        $direction = $data['direction'];
        $dateScheduled = $data['dateScheduled'];
        $scheduled = $data['scheduled'];
        $smsID = $data['id'];
        if (empty($sms_text) || empty($source_number) || empty($destination_number) || empty($dateScheduled)) {
            $GLOBALS['log']->fatal('sms_text OR source_number OR destination_number OR dateScheduled is empty');
            return false;
        }
        require_once("modules/sp_sms_log/sp_sms_log.php");
        $sp_sms_log = BeanFactory::getBean('sp_sms_log', $smsID);
        $sp_sms_log->message = $sms_text;                                        
        $sp_sms_log->date_sent = gmdate('Y-m-d H:i:s', time());
        $sp_sms_log->status = "sending";
        $sp_sms_log->direction = "outgoing";
        $sp_sms_log->destination = $destination_number;
        $sp_sms_log->dateScheduled = $dateScheduled; 
        $sp_sms_log->scheduled = $scheduled;   
        $sp_sms_log->scheduledJob = true;  
        $sp_sms_log->save();    // sending and saving SMS

        return true;        
    }
}

<?php
require_once('modules/Configurator/Configurator.php');
require_once('include/MVC/View/SugarView.php');

class ViewTwilioAdminConfig extends SugarView
{
    private $category = 'twilio';
    private $key = 'settings';

    public function __construct()
    {
        parent::SugarView();
    }

    public function display()
    {        


        //////////////////
        
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            echo '<p class="error">Twilio Ninja is no longer active due to the following reason: '.$validate_license.' Users will have limited to no access until the issue has been addressed.</p>';
            return;
            //functionality may be altered here in response to the key failing to validate
        }
        
        
        //////////////////

        global $current_user;
        if (!is_admin($current_user))
        {
            $this->ss->assign('disableButtons', true);
        }

        $system_config = new Administration();
        $system_config->retrieveSettings($this->category);
        $settings = explode('^', $system_config->settings[$this->category.'_'.$this->key]);

        $this->ss->assign('SID', $settings[0]);
        $this->ss->assign('AUTHTOKEN', $settings[1]);
        $this->ss->assign('Number', $settings[2]);

        if (!empty($_POST) && ($_POST['save'] == 'Save' || $_POST['save'] == 'Clear'))
        {
            $this->setConfig($_POST);
            SugarApplication::redirect('index.php?module=Administration&action=TwilioAdmin');
        } else {
            $GLOBALS['log']->debug('Twilio Account Informations not completely provided: Unable to save');
        }
        $this->ss->display('custom/modules/Administration/tpls/ViewTwilioAdminConfig.tpl');
    }

    private function setConfig($POST) 
    {
        $system_config = new Administration();

        // clear twilio Settings
        if ($POST['save'] == 'Clear') {
            $system_config->saveSetting($this->category, $this->key, '');
            return true;
        }
        // Save Twilio Settings 
        $system_config->saveSetting($this->category, $this->key, implode("^", array($POST['SID'],$POST['AUTHTOKEN'],$POST['Number'])));
    }
} 
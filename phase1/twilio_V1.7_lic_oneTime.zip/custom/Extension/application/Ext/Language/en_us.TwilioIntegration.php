<?php
$app_list_strings['twilio_status_list'][''] = '';
$app_list_strings['twilio_status_list']['received'] = 'Received';
$app_list_strings['twilio_status_list']['failed'] = 'Failed';
$app_list_strings['twilio_status_list']['not_enough_credit'] = 'Not Enough Credit';
$app_list_strings['twilio_status_list']['not_authorized'] = 'Not Authorized';
$app_list_strings['twilio_status_list']['sending'] = 'Sending';
$app_list_strings['twilio_status_list']['sent'] = 'Sent';
$app_list_strings['twilio_status_list']['scheduled'] = 'Scheduled';
$app_list_strings['twilio_direction_list']['incoming'] = 'Incoming';
$app_list_strings['twilio_direction_list']['outgoing'] = 'Outgoing';
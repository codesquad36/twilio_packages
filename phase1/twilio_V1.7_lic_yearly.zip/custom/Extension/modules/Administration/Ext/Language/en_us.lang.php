<?php

$mod_strings = array(
	'LBL_TWILIO_ADMIN_TITLE' => 'Twilio Administration',
	'LBL_TWILIO_ADMIN_DESC' => 'Save Twilio Account Settings',
	'LBL_TWILIO_SETTINGS' => 'Twilio Account Settings',
	'LBL_TWILIO_SETTINGS_DESC' => 'Save Twilio Account Settings',
	'LBL_TWILIONINJA_LICENSE_TITLE' => 'Twilio Ninja License',
	'LBL_TWILIONINJA_LICENSE' => 'Twilio Ninja License Configuration',
	'LBL_TWILIONINJA' => 'Twilio',
);
	
<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/SugarQueue/SugarJobQueue.php');

global $current_user;
$smsText = $_POST['smsText'];
$selectedRecordIds = $_POST['selectedRecordIds'];
$currentModule = $_POST['currentModule'];

if (empty($smsText) || empty($selectedRecordIds) || empty($currentModule)) {
	$GLOBALS['log']->error('SMS is empty or Selected records IDs not found or currentModule is not available');
	return;
}

$data = array(
	'smsText' => $smsText,
	'selectedRecordIds' => $selectedRecordIds,
	'currentModule' => $currentModule
);
$data = base64_encode(serialize($data));
$job = new SchedulersJob();
$job->name = "Send Bulk SMS : Twilio";
$job->data = $data;
$job->target = "function::SendBulkSMS";
$job->assigned_user_id = $current_user->id;
$jq = new SugarJobQueue();
$jobid = $jq->submitJob($job);

?>
<?php
	$entry_point_registry['getConfig'] = array(
	    'file' => 'modules/sp_sms_log/getConfig.php',
	    'auth' => true
	);
?>
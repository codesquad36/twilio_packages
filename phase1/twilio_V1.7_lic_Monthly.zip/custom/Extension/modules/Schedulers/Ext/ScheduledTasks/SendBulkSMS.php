<?php
array_push($job_strings, 'SendBulkSMS');

require_once('custom/include/twilioConfiguration.php');
function SendBulkSMS($job)
{    
    //////////////////
        require_once('modules/sp_sms_log/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('sp_sms_log');
        if($validate_license !== true) {
            $GLOBALS['log']->debug("Twilio Ninja is no longer active due to the following reason: ".$validate_license." Users will have limited to no access until the issue has been addressed.. ");
            return false;
            //functionality may be altered here in response to the key failing to validate
        }
    ////////////////////////////
    if (!empty($job->data))
    {
    	$data = unserialize(base64_decode($job->data));
    	$currentModule = $data['currentModule'];
    	$selectedRecordIds = $data['selectedRecordIds'];
    	$smsText = $data['smsText'];
    	if (empty($currentModule) || empty($smsText) || empty($selectedRecordIds)) {	    		
			$GLOBALS['log']->fatal('Send Bulk SMS Job Fail => SMS is empty or Selected records IDs not found or currentModule is not available');
			return false;
    	}

    	global $db;
    	$selectedRecordIds = implode('","', $selectedRecordIds);
    	$idsIn = 'IN ( "' . $selectedRecordIds . '" ) ';
    	$tabeleName = strtolower($currentModule);
    	$query = "SELECT t.phone_mobile phone from $tabeleName t where t.id " . $idsIn;
    	$records = $db->query($query);
    	while ($row = $db->fetchByAssoc($records)) {
            if (!empty($row['phone'])) {
                sendSMS($row['phone'], $smsText);
            }
    	}
        return true;        
    }
}

function sendSMS($toNumber, $smsText)
{
    require_once("modules/sp_sms_log/sp_sms_log.php");                  
    $sp_sms_log = new sp_sms_log();
    $sp_sms_log->message = $smsText;                                        
    $sp_sms_log->date_sent = gmdate('Y-m-d H:i:s', time());
    $sp_sms_log->status = "sending";
    $sp_sms_log->direction = "outgoing";
    $sp_sms_log->destination = $toNumber;  
    $sp_sms_log->scheduledJob = true;  
    $sp_sms_log->save();    // sending and saving SMS
}